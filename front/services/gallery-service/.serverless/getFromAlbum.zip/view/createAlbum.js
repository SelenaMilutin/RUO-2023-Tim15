const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient();
const createResponse = require('../utility/utils.js').createResponse;

module.exports.post = async (event, context) => {
    console.log("recieved event", JSON.stringify(event, null, 2))
    console.log("recieved context", JSON.stringify(context, null, 2))

    var s3link = event.body.s3link
    var newAlbumName = event.body.newAlbumName

    var object = {
        TableName: 'gst-serverlessAlbums',
        Item: {
          "s3Link": s3link+'/'+newAlbumName,
          "albumName": newAlbumName,
          "subAlbums": []
      }
    }

    const params = {
      TableName: 'gst-serverlessAlbums',
      Key: {
        'primaryKey': s3link,
      },
      UpdateExpression: 'SET #listField = list_append(#listField, :newItem)',
      ExpressionAttributeNames: {
        '#listField': 'subAlbums',
      },
      ExpressionAttributeValues: {
        ':newItem': s3link + '/' + newAlbumName,
      },
      ReturnValues: 'UPDATED_NEW',
    };

    try {
      await docClient.update(params).promise();
      await docClient.put(object).promise();
      return createResponse(200, 'Successfully created item!');
    } catch (error) {
      console.log(error)
      return createResponse(500, 'Error');
    }
  
}
  